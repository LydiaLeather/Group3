﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveGremlin : MonoBehaviour {

	//public static MoveGremlin moveGremlin;
	Rigidbody2D rb;

	Animator an;
	bool jump1, jump2;
	// Use this for initialization
	void Start () {
		rb = this.GetComponent<Rigidbody2D> (); 
		an = this.GetComponent<Animator> ();
		an.SetBool ("OnGround",false);
	}
	
	// Update is called once per frame
	void Update () {
		float h = Input.GetAxis ("Horizontal");

		rb.AddForce(new Vector2(h, 0), ForceMode2D.Impulse);
		//rb.velocity = new Vector2((h*10), an.velocity.y);
		an.SetFloat ("speed",Mathf.Abs(h));

		if (Input.GetKeyDown ("down") && !this.an.GetCurrentAnimatorStateInfo(0).IsName("slide")){
			an.SetBool ("slide",true);
		}
			else {
				an.SetBool ("slide",false);
			}

		if (Input.GetKeyDown ("up") && jump2) {
			rb.AddForce(new Vector2 (0, 22f), ForceMode2D.Impulse);

			an.SetBool ("OnGround",false);
			an.SetTrigger ("jump");

			if (jump1==false) {
				jump2 = false;
			}
			jump1 = false;
		}
		if (h < 0) {
			gameObject.GetComponent<SpriteRenderer> ().flipX = true;
		} else if (h >0 ){
			gameObject.GetComponent<SpriteRenderer> ().flipX = false;
		}
	}



	private void OnCollisionEnter2D(Collision2D collision){
		if (collision.transform.tag == "ground") {
			jump1 = true;
			jump2 = true;
			an.SetBool ("OnGround",true);
			//an.SetTrigger ("OnGround");
		}
	}
}
